UPDATE vaccines SET dosesReceived = dosesReceived + 5, dosesLeft = dosesLeft + 5 WHERE id = 1;

