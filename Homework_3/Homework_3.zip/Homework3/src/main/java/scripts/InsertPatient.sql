INSERT INTO patients (name, vaccineID, firstDoseDate, secondDoseDate)
VALUES ('John Doe', 1, '2023-04-15', '2023-05-06');