INSERT INTO vaccines (name, dosesRequired, daysBetweenDoses, dosesReceived, dosesLeft)
VALUES ('Moderna', 2, 28, 100, 100);